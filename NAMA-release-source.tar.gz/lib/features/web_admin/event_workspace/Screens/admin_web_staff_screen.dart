// lib/features/web_admin/event_workspace/Screens/admin_web_staff_screen.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:cloud_functions/cloud_functions.dart';
import 'package:flutter/material.dart';
import '../../admin_web_theme.dart';
import '../utils/admin_event_user_delete_helper.dart';
class AdminWebStaffScreen extends StatefulWidget {
  final String eventId;
  final String eventName;
  const AdminWebStaffScreen({
    super.key,
    required this.eventId,
    required this.eventName,
  });
  @override
  State<AdminWebStaffScreen> createState() =>
      _AdminWebStaffScreenState();
}
class _AdminWebStaffScreenState extends State<AdminWebStaffScreen> {
  final TextEditingController _searchController =
      TextEditingController();
  String _searchQuery = '';
  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
  Stream<QuerySnapshot<Map<String, dynamic>>> _staffStream() {
    return FirebaseFirestore.instance
        .collection('users')
        .where('role', isEqualTo: 'staff')
        .where('eventIds', arrayContains: widget.eventId)
        .snapshots();
  }
  Future<void> _openCreateStaffDialog() async {
    await showDialog<void>(
      context: context,
      barrierDismissible: false,
      builder: (_) => _CreateStaffDialog(
        eventId: widget.eventId,
        eventName: widget.eventName,
      ),
    );
  }
Future<void> _openEditStaffDialog({
  required String staffId,
  required Map<String, dynamic> staffData,
}) async {
  await showDialog<void>(
    context: context,
    barrierDismissible: false,
    builder: (_) => _EditStaffDialog(
      eventId: widget.eventId,
      eventName: widget.eventName,
      staffId: staffId,
      staffData: staffData,
    ),
  );
}
  Future<void> _confirmDeleteStaff({
    required String staffId,
    required Map<String, dynamic> staffData,
  }) async {
    final name = (staffData['name'] ?? 'this staff member').toString();
    final email = (staffData['email'] ?? '').toString();
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text('Delete staff member'),
          content: Text(
            'Are you sure you want to remove $name${email.isNotEmpty ? ' ($email)' : ''} from ${widget.eventName}?\n\nThis will remove this user from this event, attendance, merchandise collection, session assignments, meetings, and certificates.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton.icon(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              icon: const Icon(Icons.delete_outline_rounded, size: 17),
              label: const Text('Delete'),
              style: FilledButton.styleFrom(
                backgroundColor: Colors.redAccent,
                foregroundColor: Colors.white,
              ),
            ),
          ],
        );
      },
    );
    if (confirmed != true) return;
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Removing staff member...')),
    );
    try {
      await AdminEventUserDeleteHelper.deleteUserFromEvent(
        eventId: widget.eventId,
        userId: staffId,
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('$name removed from this event.'),
          backgroundColor: AdminWebTheme.success,
        ),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to delete staff member: $e'),
          backgroundColor: Colors.redAccent,
        ),
      );
    }
  }
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _StaffPageHeader(
              eventName: widget.eventName,
              onCreateStaff: _openCreateStaffDialog,
            ),
          const SizedBox(height: 20),
          _SearchBar(
            controller: _searchController,
            onChanged: (value) {
              setState(() {
                _searchQuery = value.trim().toLowerCase();
              });
            },
            onClear: () {
              _searchController.clear();
              setState(() => _searchQuery = '');
            },
          ),
          const SizedBox(height: 18),
          StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: _staffStream(),
            builder: (context, snapshot) {
              if (snapshot.connectionState ==
                  ConnectionState.waiting) {
                return const _LoadingCard();
              }
              if (snapshot.hasError) {
                return _MessageCard(
                  icon: Icons.error_outline_rounded,
                  title: 'Could not load users',
                  message: snapshot.error.toString(),
                );
              }
              final staffMembers = [...?snapshot.data?.docs]
                ..sort((a, b) {
                  final aName =
                      (a.data()['name'] ?? '').toString();
                  final bName =
                      (b.data()['name'] ?? '').toString();
                  return aName
                      .toLowerCase()
                      .compareTo(bName.toLowerCase());
                });
              final filtered = staffMembers.where((staffMember) {
                if (_searchQuery.isEmpty) return true;
                final data = staffMember.data();
                final searchable = [
                  data['name'],
                  data['email'],
                  data['company'],
                  data['position'],
                  data['phone'],
                  data['country'],
                  data['linkedin'],
                  data['twitter'],
                  data['website'],
                  data['github'],
                  data['medium'],
                  data['instagram'],
                ].map((value) {
                  return (value ?? '')
                      .toString()
                      .toLowerCase();
                }).join(' ');
                return searchable.contains(_searchQuery);
              }).toList();
              if (filtered.isEmpty) {
                return _MessageCard(
                  icon: Icons.people_outline_rounded,
                  title: staffMembers.isEmpty
                      ? 'No staff members found'
                      : 'No matching staff members',
                  message: staffMembers.isEmpty
                      ? 'No staff accounts are currently linked to ${widget.eventName}.'
                      : 'Try searching with a different name, email, company, phone number, country, or social profile.',
                );
              }
              return _StaffTable(
                staffMembers: filtered,
                onEdit: (staffId, staffData) {
                  _openEditStaffDialog(
                    staffId: staffId,
                    staffData: staffData,
                  );
                },
                onDelete: (staffId, staffData) {
                  _confirmDeleteStaff(
                    staffId: staffId,
                    staffData: staffData,
                  );
                },
              );
            },
          ),
        ],
      ),
    );
  }
}
class _StaffPageHeader extends StatelessWidget {
  final String eventName;
  final VoidCallback onCreateStaff;
  const _StaffPageHeader({
    required this.eventName,
    required this.onCreateStaff,
  });
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final compact = constraints.maxWidth < 650;
        final titleSection = Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              eventName.toUpperCase(),
              style: const TextStyle(
                color: AdminWebTheme.primary,
                fontSize: 10,
                fontWeight: FontWeight.w800,
                letterSpacing: 1.2,
              ),
            ),
            const SizedBox(height: 7),
            const Text(
              'Staff',
              style: TextStyle(
                color: AdminWebTheme.textPrimary,
                fontSize: 27,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 7),
            const Text(
              'Create staff accounts, send invitation emails, view staff information, and edit profile fields when needed.',
              style: TextStyle(
                color: AdminWebTheme.textSecondary,
                fontSize: 12,
                height: 1.5,
              ),
            ),
          ],
        );
        final createButton = FilledButton.icon(
          onPressed: onCreateStaff,
          icon: const Icon(
            Icons.person_add_alt_1_rounded,
            size: 18,
          ),
          label: const Text('Create Staff'),
          style: FilledButton.styleFrom(
            backgroundColor: AdminWebTheme.primary,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(
              horizontal: 18,
              vertical: 16,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
            textStyle: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
            ),
          ),
        );
        if (compact) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              titleSection,
              const SizedBox(height: 16),
              createButton,
            ],
          );
        }
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(child: titleSection),
            const SizedBox(width: 20),
            createButton,
          ],
        );
      },
    );
  }
}
class _SearchBar extends StatelessWidget {
  final TextEditingController controller;
  final ValueChanged<String> onChanged;
  final VoidCallback onClear;
  const _SearchBar({
    required this.controller,
    required this.onChanged,
    required this.onClear,
  });
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(13),
        border: Border.all(
          color: AdminWebTheme.border,
        ),
      ),
      child: TextField(
        controller: controller,
        onChanged: onChanged,
        decoration: InputDecoration(
          hintText:
              'Search staff by name, email, company, phone, country, or social profile',
          prefixIcon: const Icon(
            Icons.search_rounded,
            size: 19,
          ),
          suffixIcon: controller.text.isEmpty
              ? null
              : IconButton(
                  onPressed: onClear,
                  icon: const Icon(
                    Icons.close_rounded,
                    size: 18,
                  ),
                ),
          filled: true,
          fillColor: const Color(0xFFFAFBFD),
          contentPadding: const EdgeInsets.symmetric(
            horizontal: 14,
            vertical: 13,
          ),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(
              color: AdminWebTheme.border,
            ),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(
              color: AdminWebTheme.border,
            ),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(10),
            borderSide: const BorderSide(
              color: AdminWebTheme.primary,
            ),
          ),
        ),
      ),
    );
  }
}
class _StaffTable extends StatelessWidget {
  final List<QueryDocumentSnapshot<Map<String, dynamic>>> staffMembers;
  final void Function(
    String userId,
    Map<String, dynamic> userData,
  ) onEdit;
  final void Function(
    String userId,
    Map<String, dynamic> userData,
  ) onDelete;
  const _StaffTable({
    required this.staffMembers,
    required this.onEdit,
    required this.onDelete,
  });
  @override
  Widget build(BuildContext context) {
    return Container(
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(13),
        border: Border.all(
          color: AdminWebTheme.border,
        ),
      ),
      child: LayoutBuilder(
        builder: (context, constraints) {
          if (constraints.maxWidth < 850) {
            return Column(
              children: staffMembers.map((staffMember) {
                return _MobileStaffCard(
                  data: staffMember.data(),
                  onEdit: () => onEdit(
                    staffMember.id,
                    staffMember.data(),
                  ),
                  onDelete: () => onDelete(
                    staffMember.id,
                    staffMember.data(),
                  ),
                );
              }).toList(),
            );
          }
          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: ConstrainedBox(
              constraints: BoxConstraints(
                minWidth: constraints.maxWidth,
              ),
              child: DataTable(
                headingRowColor: WidgetStateProperty.all(
                  const Color(0xFFFAFBFD),
                ),
                headingRowHeight: 46,
                dataRowMinHeight: 48,
                dataRowMaxHeight: 54,
                headingTextStyle: const TextStyle(
                  color: AdminWebTheme.textSecondary,
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  letterSpacing: 0.3,
                ),
                dataTextStyle: const TextStyle(
                  color: AdminWebTheme.textPrimary,
                  fontSize: 10.5,
                  fontWeight: FontWeight.w500,
                ),
              columnSpacing: 26,
              horizontalMargin: 18,
              columns: const [
                DataColumn(label: Text('USER')),
                DataColumn(label: Text('COMPANY')),
                DataColumn(label: Text('PHONE')),
                DataColumn(label: Text('COUNTRY')),
                DataColumn(label: Text('ROLE')),
                DataColumn(label: Text('STATUS')),
                DataColumn(label: Text('ACTIONS')),
              ],
              rows: staffMembers.map((staffMember) {
                final data = staffMember.data();
                final name =
                    (data['name'] ?? 'Unnamed User').toString();
                final email =
                    (data['email'] ?? '').toString();
                final company =
                    (data['company'] ?? '—').toString();
                final phone =
                    (data['phone'] ?? '—').toString();
                final country =
                    (data['country'] ?? '—').toString();
                final role =
                    (data['role'] ?? 'attendee').toString();
                final status =
                    (data['status'] ?? 'approved').toString();
                return DataRow(
                  cells: [
                    DataCell(
                      SizedBox(
                        width: 230,
                        child: Row(
                          children: [
                            _StaffAvatar(
                              imageUrl:
                                  (data['profileImageUrl'] ?? '')
                                      .toString(),
                              name: name,
                            ),
                            const SizedBox(width: 11),
                            Expanded(
                              child: Column(
                                mainAxisAlignment:
                                    MainAxisAlignment.center,
                                crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    name,
                                    maxLines: 1,
                                    overflow:
                                        TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color:
                                          AdminWebTheme.textPrimary,
                                      fontSize: 11,
                                      fontWeight:
                                          FontWeight.w700,
                                    ),
                                  ),
                                  const SizedBox(height: 3),
                                  Text(
                                    email,
                                    maxLines: 1,
                                    overflow:
                                        TextOverflow.ellipsis,
                                    style: const TextStyle(
                                      color: AdminWebTheme
                                          .textSecondary,
                                      fontSize: 8.5,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    DataCell(
                      SizedBox(
                        width: 150,
                        child: Text(
                          company.isEmpty ? '—' : company,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ),
                    DataCell(Text(phone.isEmpty ? '—' : phone)),
                    DataCell(Text(country.isEmpty ? '—' : country)),
                    DataCell(_RoleBadge(role: role)),
                    DataCell(
                      _StatusBadge(
                        active:
                            status.toLowerCase() == 'approved',
                        activeText: 'Approved',
                        inactiveText: _capitalize(status),
                      ),
                    ),
                    DataCell(
                      _TableActions(
                        onEdit: () => onEdit(staffMember.id, data),
                        onDelete: () => onDelete(staffMember.id, data),
                      ),
                    ),
                  ],
                );
                }).toList(),
              ),
            ),
          );
        },
      ),
    );
  }
  static String _capitalize(String value) {
    if (value.isEmpty) return 'Unknown';
    return value[0].toUpperCase() +
        value.substring(1).toLowerCase();
  }
}
class _TableActions extends StatelessWidget {
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  const _TableActions({
    required this.onEdit,
    required this.onDelete,
  });
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        OutlinedButton.icon(
          onPressed: onEdit,
          icon: const Icon(Icons.edit_outlined, size: 17),
          label: const Text('Edit'),
          style: OutlinedButton.styleFrom(
            foregroundColor: AdminWebTheme.primary,
            side: const BorderSide(color: AdminWebTheme.border),
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            minimumSize: const Size(72, 34),
            textStyle: const TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
        const SizedBox(width: 6),
        IconButton(
          tooltip: 'Delete',
          onPressed: onDelete,
          icon: const Icon(Icons.delete_outline_rounded, size: 18),
          color: AdminWebTheme.danger,
          visualDensity: VisualDensity.compact,
        ),
      ],
    );
  }
}
class _MobileStaffCard extends StatelessWidget {
  final Map<String, dynamic> data;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  const _MobileStaffCard({
    required this.data,
    required this.onEdit,
    required this.onDelete,
  });
  @override
  Widget build(BuildContext context) {
    final name =
        (data['name'] ?? 'Unnamed User').toString();
    final email = (data['email'] ?? '').toString();
    final company = (data['company'] ?? '').toString();
    final role = (data['role'] ?? 'attendee').toString();
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: const BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: AdminWebTheme.border,
          ),
        ),
      ),
      child: Column(
        children: [
          Row(
            children: [
              _StaffAvatar(
                imageUrl:
                    (data['profileImageUrl'] ?? '').toString(),
                name: name,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    Text(
                      name,
                      style: const TextStyle(
                        color: AdminWebTheme.textPrimary,
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      email,
                      style: const TextStyle(
                        color: AdminWebTheme.textSecondary,
                        fontSize: 10.5,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                tooltip: 'Edit staff',
                onPressed: onEdit,
                icon: const Icon(
                  Icons.edit_outlined,
                  color: AdminWebTheme.primary,
                ),
              ),
              IconButton(
                tooltip: 'Delete staff',
                onPressed: onDelete,
                icon: const Icon(
                  Icons.delete_outline_rounded,
                  color: Colors.redAccent,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _SmallInfo(
                  label: 'Company',
                  value: company.isEmpty ? '—' : company,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _SmallInfo(
                  label: 'Role',
                  value: role,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _SmallInfo(
                  label: 'Status',
                  value:
                      (data['status'] ?? 'approved').toString(),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
class _CreateStaffDialog extends StatefulWidget {
  final String eventId;
  final String eventName;
  const _CreateStaffDialog({
    required this.eventId,
    required this.eventName,
  });
  @override
  State<_CreateStaffDialog> createState() =>
      _CreateStaffDialogState();
}
class _CreateStaffDialogState extends State<_CreateStaffDialog> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _companyController = TextEditingController();
  bool _saving = false;
  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _companyController.dispose();
    super.dispose();
  }
  Future<void> _createStaff() async {
    FocusScope.of(context).unfocus();
    if (_saving || !_formKey.currentState!.validate()) {
      return;
    }
    setState(() => _saving = true);
    final name = _nameController.text.trim();
    final email = _emailController.text.trim().toLowerCase();
    final company = _companyController.text.trim();
    try {
      final callable = FirebaseFunctions.instanceFor(
        region: 'asia-southeast1',
      ).httpsCallable('createEventRoleAccount');
      final result = await callable.call({
        'name': name,
        'email': email,
        'company': company,
        'role': 'staff',
        'eventId': widget.eventId,
        'eventName': widget.eventName,
      });
      final data = Map<String, dynamic>.from(
        result.data as Map,
      );
      final accountCreated = data['accountCreated'] == true;
      final invitationSent = data['invitationSent'] == true;
      final existingInvitationSent =
          data['existingInvitationSent'] == true ||
              data['verificationEmailSent'] == true;
      if (!mounted) return;
      Navigator.of(context).pop();
      await showDialog<void>(
        context: context,
        builder: (dialogContext) {
          final message = accountCreated
              ? invitationSent
                  ? '$name has been created and added to ${widget.eventName}.\n\n'
                      'An invitation email with username and temporary password has been sent to $email.'
                  : '$name was created and added to ${widget.eventName}, but the invitation email was not sent.'
              : existingInvitationSent
                  ? '$name already had a NAMA Events account and has been added to ${widget.eventName}.\n\n'
                      'An invitation email has been sent to $email.'
                  : '$name has been added to ${widget.eventName}.';
          return AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
            title: Text(
              accountCreated ? 'Staff Created' : 'Staff Added',
              style: const TextStyle(
                fontWeight: FontWeight.w800,
              ),
            ),
            content: Text(message),
            actions: [
              FilledButton(
                onPressed: () => Navigator.of(dialogContext).pop(),
                child: const Text('Done'),
              ),
            ],
          );
        },
      );
    } on FirebaseFunctionsException catch (error) {
      _showError(error.message ?? error.code);
    } catch (error) {
      _showError(
        error.toString().replaceFirst('Exception: ', ''),
      );
    } finally {
      if (mounted) {
        setState(() => _saving = false);
      }
    }
  }
  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.redAccent,
      ),
    );
  }
  @override
  Widget build(BuildContext context) {
    return _WebDialogFrame(
      width: 650,
      title: 'Create Staff',
      subtitle:
          'Create a staff account for ${widget.eventName}. The staff member will receive an invitation email with username and temporary password.',
      icon: Icons.person_add_alt_1_rounded,
      onClose: _saving ? null : () => Navigator.of(context).pop(),
      child: Form(
        key: _formKey,
        child: Column(
          children: [
            _EditableField(
              label: 'Full Name',
              hint: 'Enter staff name',
              controller: _nameController,
              icon: Icons.person_outline_rounded,
              validator: (value) {
                if (value == null || value.trim().isEmpty) {
                  return 'Staff name is required';
                }
                return null;
              },
            ),
            const SizedBox(height: 14),
            _EditableField(
              label: 'Email Address',
              hint: 'staff@example.com',
              controller: _emailController,
              icon: Icons.email_outlined,
              keyboardType: TextInputType.emailAddress,
              validator: (value) {
                final email = value?.trim() ?? '';
                if (email.isEmpty) {
                  return 'Email is required';
                }
                if (!email.contains('@') || !email.contains('.')) {
                  return 'Enter a valid email address';
                }
                return null;
              },
            ),
            const SizedBox(height: 14),
            _EditableField(
              label: 'Company / Organisation',
              hint: 'Enter organisation or department',
              controller: _companyController,
              icon: Icons.business_outlined,
            ),
            const SizedBox(height: 22),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                TextButton(
                  onPressed:
                      _saving ? null : () => Navigator.of(context).pop(),
                  child: const Text('Cancel'),
                ),
                const SizedBox(width: 10),
                FilledButton.icon(
                  onPressed: _saving ? null : _createStaff,
                  icon: _saving
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Icon(
                          Icons.send_rounded,
                          size: 17,
                        ),
                  label: Text(
                    _saving ? 'Creating...' : 'Create & Invite',
                  ),
                  style: FilledButton.styleFrom(
                    backgroundColor: AdminWebTheme.primary,
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(
                      horizontal: 18,
                      vertical: 14,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(11),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
class _EditStaffDialog extends StatefulWidget {
  final String eventId;
  final String eventName;
  final String staffId;
  final Map<String, dynamic> staffData;
  const _EditStaffDialog({
    required this.eventId,
    required this.eventName,
    required this.staffId,
    required this.staffData,
  });
  @override
  State<_EditStaffDialog> createState() =>
      _EditStaffDialogState();
}
class _EditStaffDialogState extends State<_EditStaffDialog> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _emailController;
  late final TextEditingController _companyController;
  late final TextEditingController _positionController;
  late final TextEditingController _phoneController;
  late final TextEditingController _countryController;
  late final TextEditingController _bioController;
  late final TextEditingController _linkedInController;
  late final TextEditingController _twitterController;
  late final TextEditingController _websiteController;
  late final TextEditingController _githubController;
  late final TextEditingController _mediumController;
  late final TextEditingController _instagramController;
  late final TextEditingController _profileImageController;
  late String _selectedRole;
  late String _status;
  bool _statusSaving = false;
  late String _profileVisibility;
  bool _saving = false;
  static const Map<String, String> _roles = {
    'attendee': 'Attendee',
    'staff': 'Staff',
    'speaker': 'Speaker',
    'moderator': 'Moderator',
    'admin': 'Admin',
  };
  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(
      text: (widget.staffData['name'] ?? '').toString(),
    );
    _emailController = TextEditingController(
      text: (widget.staffData['email'] ?? '').toString(),
    );
    _companyController = TextEditingController(
      text: (widget.staffData['company'] ?? '').toString(),
    );
    _positionController = TextEditingController(
      text: (widget.staffData['position'] ??
              widget.staffData['jobTitle'] ??
              '')
          .toString(),
    );
    _phoneController = TextEditingController(
      text: (widget.staffData['phone'] ??
              widget.staffData['phoneNumber'] ??
              '')
          .toString(),
    );
    _countryController = TextEditingController(
      text: (widget.staffData['country'] ?? '').toString(),
    );
    _bioController = TextEditingController(
      text: (widget.staffData['bio'] ?? '').toString(),
    );
    _linkedInController = TextEditingController(
      text: (widget.staffData['linkedin'] ??
              widget.staffData['linkedIn'] ??
              '')
          .toString(),
    );
    _twitterController = TextEditingController(
      text: (widget.staffData['twitter'] ?? '').toString(),
    );
    _websiteController = TextEditingController(
      text: (widget.staffData['website'] ?? '').toString(),
    );
    _githubController = TextEditingController(
      text: (widget.staffData['github'] ?? '').toString(),
    );
    _mediumController = TextEditingController(
      text: (widget.staffData['medium'] ?? '').toString(),
    );
    _instagramController = TextEditingController(
      text: (widget.staffData['instagram'] ?? '').toString(),
    );
    _profileImageController = TextEditingController(
      text: (widget.staffData['profileImageUrl'] ?? '').toString(),
    );
    final currentRole =
        (widget.staffData['role'] ?? 'staff')
            .toString()
            .toLowerCase();
    _selectedRole =
        _roles.containsKey(currentRole) ? currentRole : 'staff';
    final rawStatus =
        (widget.staffData['status'] ?? 'approved')
            .toString()
            .toLowerCase();
    _status = rawStatus == 'approved' ? 'approved' : 'pending';
    final visibility =
        (widget.staffData['profileVisibility'] ?? 'full')
            .toString()
            .toLowerCase();
    _profileVisibility = const [
      'full',
      'limited',
      'private',
    ].contains(visibility)
        ? visibility
        : 'full';
  }
  @override
  void dispose() {
    _nameController.dispose();
    _emailController.dispose();
    _companyController.dispose();
    _positionController.dispose();
    _phoneController.dispose();
    _countryController.dispose();
    _bioController.dispose();
    _linkedInController.dispose();
    _twitterController.dispose();
    _websiteController.dispose();
    _githubController.dispose();
    _mediumController.dispose();
    _instagramController.dispose();
    _profileImageController.dispose();
    super.dispose();
  }

  Future<void> _changeAccountStatus(String? value) async {
    if (value == null || value == _status || _saving || _statusSaving) return;

    final previous = _status;
    setState(() {
      _status = value;
      _statusSaving = true;
    });

    try {
      await FirebaseFirestore.instance
          .collection('users')
          .doc(widget.staffId)
          .update({
            'status': value,
            'updatedAt': FieldValue.serverTimestamp(),
          });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Account status updated.')),
        );
      }
    } catch (error) {
      if (mounted) {
        setState(() => _status = previous);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to update status: $error'),
            backgroundColor: Colors.redAccent,
          ),
        );
      }
    } finally {
      if (mounted) setState(() => _statusSaving = false);
    }
  }

  Future<bool> _confirmRoleChange() async {
    final oldRole =
        (widget.staffData['role'] ?? 'staff')
            .toString()
            .toLowerCase();
    if (oldRole == _selectedRole) return true;
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          title: const Text(
            'Change Staff Role?',
            style: TextStyle(
              fontWeight: FontWeight.w800,
            ),
          ),
          content: Text(
            'This staff member will be changed from '
            '${_roles[oldRole] ?? oldRole} to '
            '${_roles[_selectedRole] ?? _selectedRole}.\n\n'
            'After saving, the staff member may move to another management page and disappear from the Staff page.',
          ),
          actions: [
            TextButton(
              onPressed: () =>
                  Navigator.of(dialogContext).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () =>
                  Navigator.of(dialogContext).pop(true),
              child: const Text('Change Role'),
            ),
          ],
        );
      },
    );
    return confirmed == true;
  }
  Future<void> _saveChanges() async {
    FocusScope.of(context).unfocus();
    if (_saving || _statusSaving || !_formKey.currentState!.validate()) {
      return;
    }
    final confirmed = await _confirmRoleChange();
    if (!confirmed) return;
    setState(() => _saving = true);
    try {
      final reference = FirebaseFirestore.instance
          .collection('users')
          .doc(widget.staffId);
      await reference.set({
        'name': _nameController.text.trim(),
        'company': _companyController.text.trim(),
        'position': _positionController.text.trim(),
        'jobTitle': _positionController.text.trim(),
        'phone': _phoneController.text.trim(),
        'phoneNumber': _phoneController.text.trim(),
        'country': _countryController.text.trim(),
        'bio': _bioController.text.trim(),
        'linkedin': _linkedInController.text.trim(),
        'linkedIn': _linkedInController.text.trim(),
        'twitter': _twitterController.text.trim(),
        'website': _websiteController.text.trim(),
        'github': _githubController.text.trim(),
        'medium': _mediumController.text.trim(),
        'instagram': _instagramController.text.trim(),
        'profileImageUrl': _profileImageController.text.trim(),
        'role': _selectedRole,
        'status': _status,
        'profileVisibility': _profileVisibility,
        'eventIds': FieldValue.arrayUnion([widget.eventId]),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
      if (!mounted) return;
      Navigator.of(context).pop();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            '${_nameController.text.trim()} was updated successfully.',
          ),
          behavior: SnackBarBehavior.floating,
        ),
      );
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Failed to update staff member: $error',
          ),
          behavior: SnackBarBehavior.floating,
          backgroundColor: Colors.redAccent,
        ),
      );
    } finally {
      if (mounted) {
        setState(() => _saving = false);
      }
    }
  }
  @override
  Widget build(BuildContext context) {
    return _WebDialogFrame(
      width: 980,
      title: 'Edit Staff',
      subtitle:
          'Review and update staff profile information for ${widget.eventName}.',
      icon: Icons.manage_accounts_outlined,
      onClose:
          _saving ? null : () => Navigator.of(context).pop(),
      child: Form(
        key: _formKey,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _ProfileSummary(
              nameController: _nameController,
              emailController: _emailController,
              imageController: _profileImageController,
            ),
            const SizedBox(height: 16),
            _DialogSection(
              title: 'Personal Information',
              subtitle:
                  'Edit the profile fields shown to other users.',
              child: Column(
                children: [
                  _ResponsiveDialogFields(
                    children: [
                      _EditableField(
                        label: 'Full Name',
                        hint: 'Enter full name',
                        controller: _nameController,
                        icon: Icons.person_outline_rounded,
                        validator: (value) {
                          if (value == null ||
                              value.trim().isEmpty) {
                            return 'Name is required';
                          }
                          return null;
                        },
                      ),
                      _EditableField(
                        label: 'Email Address',
                        hint: '',
                        controller: _emailController,
                        icon: Icons.mail_outline_rounded,
                        enabled: false,
                        allowClear: false,
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _ResponsiveDialogFields(
                    children: [
                      _EditableField(
                        label: 'Company / Organisation',
                        hint: 'Enter company',
                        controller: _companyController,
                        icon: Icons.business_outlined,
                      ),
                      _EditableField(
                        label: 'Job Title',
                        hint: 'Enter job title',
                        controller: _positionController,
                        icon: Icons.badge_outlined,
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _ResponsiveDialogFields(
                    children: [
                      _EditableField(
                        label: 'Phone Number',
                        hint: 'Enter phone number',
                        controller: _phoneController,
                        icon: Icons.phone_outlined,
                        keyboardType: TextInputType.phone,
                      ),
                      _EditableField(
                        label: 'Country',
                        hint: 'Enter country',
                        controller: _countryController,
                        icon: Icons.public_rounded,
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _EditableField(
                    label: 'Bio',
                    hint: 'Enter biography',
                    controller: _bioController,
                    icon: Icons.notes_rounded,
                    maxLines: 5,
                  ),
                  const SizedBox(height: 14),
                  _EditableField(
                    label: 'Profile Image URL',
                    hint: 'Paste the profile image URL',
                    controller: _profileImageController,
                    icon: Icons.image_outlined,
                    keyboardType: TextInputType.url,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _DialogSection(
              title: 'Social Profiles',
              subtitle:
                  'Add, update, or remove the user’s social links.',
              child: Column(
                children: [
                  _ResponsiveDialogFields(
                    children: [
                      _EditableField(
                        label: 'LinkedIn',
                        hint: 'LinkedIn profile URL',
                        controller: _linkedInController,
                        icon: Icons.link_rounded,
                        keyboardType: TextInputType.url,
                      ),
                      _EditableField(
                        label: 'Twitter / X',
                        hint: 'Twitter or X profile URL',
                        controller: _twitterController,
                        icon: Icons.alternate_email_rounded,
                        keyboardType: TextInputType.url,
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _ResponsiveDialogFields(
                    children: [
                      _EditableField(
                        label: 'Website',
                        hint: 'Website URL',
                        controller: _websiteController,
                        icon: Icons.language_rounded,
                        keyboardType: TextInputType.url,
                      ),
                      _EditableField(
                        label: 'GitHub',
                        hint: 'GitHub profile URL',
                        controller: _githubController,
                        icon: Icons.code_rounded,
                        keyboardType: TextInputType.url,
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _ResponsiveDialogFields(
                    children: [
                      _EditableField(
                        label: 'Medium',
                        hint: 'Medium profile URL',
                        controller: _mediumController,
                        icon: Icons.article_outlined,
                        keyboardType: TextInputType.url,
                      ),
                      _EditableField(
                        label: 'Instagram',
                        hint: 'Instagram profile URL',
                        controller: _instagramController,
                        icon: Icons.photo_camera_outlined,
                        keyboardType: TextInputType.url,
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            _DialogSection(
              title: 'Role & Access',
              subtitle:
                  'Changing the role changes which interface and management page the user belongs to.',
              child: Column(
                children: [
                  _ResponsiveDialogFields(
                    children: [
                      _DialogDropdown(
                        label: 'User Role',
                        value: _selectedRole,
                        icon:
                            Icons.admin_panel_settings_outlined,
                        items: _roles,
                        onChanged: (value) {
                          if (value == null) return;
                          setState(() {
                            _selectedRole = value;
                          });
                        },
                      ),
                      _DialogDropdown(
                        key: ValueKey('staff-status-$_status'),
                        label: 'Account Status',
                        value: _status,
                        icon: Icons.verified_user_outlined,
                        items: const {
                          'approved': 'Approved',
                          'pending': 'Pending',
                        },
                        onChanged: _statusSaving || _saving
                            ? null
                            : _changeAccountStatus,
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  _DialogDropdown(
                    label: 'Profile Visibility',
                    value: _profileVisibility,
                    icon: Icons.visibility_outlined,
                    items: const {
                      'full': 'Full',
                      'limited': 'Limited',
                      'private': 'Private',
                    },
                    onChanged: (value) {
                      if (value == null) return;
                      setState(() {
                        _profileVisibility = value;
                      });
                    },
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            _DialogActions(
              saving: _saving || _statusSaving,
              onCancel: () => Navigator.of(context).pop(),
              onSubmit: _saveChanges,
            ),
          ],
        ),
      ),
    );
  }
}
class _ProfileSummary extends StatelessWidget {
  final TextEditingController nameController;
  final TextEditingController emailController;
  final TextEditingController imageController;
  const _ProfileSummary({
    required this.nameController,
    required this.emailController,
    required this.imageController,
  });
  @override
  Widget build(BuildContext context) {
    final name = nameController.text.trim();
    final imageUrl = imageController.text.trim();
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(13),
        border: Border.all(
          color: AdminWebTheme.border,
        ),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 34,
            backgroundColor:
                AdminWebTheme.primary.withOpacity(0.10),
            backgroundImage:
                imageUrl.isEmpty ? null : NetworkImage(imageUrl),
            child: imageUrl.isEmpty
                ? Text(
                    name.isEmpty ? 'S' : name[0].toUpperCase(),
                    style: const TextStyle(
                      color: AdminWebTheme.primary,
                      fontSize: 22,
                      fontWeight: FontWeight.w800,
                    ),
                  )
                : null,
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name.isEmpty ? 'Unnamed User' : name,
                  style: const TextStyle(
                    color: AdminWebTheme.textPrimary,
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  emailController.text,
                  style: const TextStyle(
                    color: AdminWebTheme.textSecondary,
                    fontSize: 10.5,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
class _EditableField extends StatelessWidget {
  final String label;
  final String hint;
  final TextEditingController controller;
  final IconData icon;
  final String? Function(String?)? validator;
  final TextInputType? keyboardType;
  final bool enabled;
  final bool allowClear;
  final int maxLines;
  const _EditableField({
    required this.label,
    required this.hint,
    required this.controller,
    required this.icon,
    this.validator,
    this.keyboardType,
    this.enabled = true,
    this.allowClear = true,
    this.maxLines = 1,
  });
  @override
  Widget build(BuildContext context) {
    return StatefulBuilder(
      builder: (context, setLocalState) {
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _FieldLabel(label),
            const SizedBox(height: 7),
            TextFormField(
              controller: controller,
              enabled: enabled,
              validator: validator,
              keyboardType: keyboardType,
              maxLines: maxLines,
              onChanged: (_) => setLocalState(() {}),
              decoration: _dialogInputDecoration(
                hint: hint,
                icon: icon,
              ).copyWith(
                suffixIcon: enabled &&
                        allowClear &&
                        controller.text.trim().isNotEmpty
                    ? IconButton(
                        tooltip: 'Clear $label',
                        onPressed: () {
                          controller.clear();
                          setLocalState(() {});
                        },
                        icon: const Icon(
                          Icons.delete_outline_rounded,
                          color: Colors.redAccent,
                          size: 19,
                        ),
                      )
                    : null,
              ),
            ),
          ],
        );
      },
    );
  }
}
class _WebDialogFrame extends StatelessWidget {
  final double width;
  final String title;
  final String subtitle;
  final IconData icon;
  final VoidCallback? onClose;
  final Widget child;
  const _WebDialogFrame({
    required this.width,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.onClose,
    required this.child,
  });
  @override
  Widget build(BuildContext context) {
    return Dialog(
      insetPadding: const EdgeInsets.all(24),
      backgroundColor: Colors.transparent,
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: width,
          maxHeight:
              MediaQuery.sizeOf(context).height - 48,
        ),
        child: Container(
          decoration: BoxDecoration(
            color: const Color(0xFFF7F8FC),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(
            children: [
              Container(
                padding: const EdgeInsets.all(20),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.vertical(
                    top: Radius.circular(16),
                  ),
                  border: Border(
                    bottom: BorderSide(
                      color: AdminWebTheme.border,
                    ),
                  ),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 43,
                      height: 43,
                      decoration: BoxDecoration(
                        color: AdminWebTheme.primary
                            .withOpacity(0.08),
                        borderRadius:
                            BorderRadius.circular(11),
                      ),
                      child: Icon(
                        icon,
                        color: AdminWebTheme.primary,
                        size: 21,
                      ),
                    ),
                    const SizedBox(width: 13),
                    Expanded(
                      child: Column(
                        crossAxisAlignment:
                            CrossAxisAlignment.start,
                        children: [
                          Text(
                            title,
                            style: const TextStyle(
                              color:
                                  AdminWebTheme.textPrimary,
                              fontSize: 17,
                              fontWeight: FontWeight.w800,
                            ),
                          ),
                          const SizedBox(height: 4),
                          Text(
                            subtitle,
                            style: const TextStyle(
                              color: AdminWebTheme
                                  .textSecondary,
                              fontSize: 10.5,
                              height: 1.4,
                            ),
                          ),
                        ],
                      ),
                    ),
                    IconButton(
                      onPressed: onClose,
                      icon: const Icon(
                        Icons.close_rounded,
                      ),
                    ),
                  ],
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(20),
                  child: child,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
class _DialogSection extends StatelessWidget {
  final String title;
  final String subtitle;
  final Widget child;
  const _DialogSection({
    required this.title,
    required this.subtitle,
    required this.child,
  });
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(13),
        border: Border.all(
          color: AdminWebTheme.border,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title,
            style: const TextStyle(
              color: AdminWebTheme.textPrimary,
              fontSize: 13,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            subtitle,
            style: const TextStyle(
              color: AdminWebTheme.textSecondary,
              fontSize: 9.5,
            ),
          ),
          const SizedBox(height: 16),
          child,
        ],
      ),
    );
  }
}
class _ResponsiveDialogFields extends StatelessWidget {
  final List<Widget> children;
  const _ResponsiveDialogFields({
    required this.children,
  });
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 620) {
          return Column(
            children: [
              for (int index = 0;
                  index < children.length;
                  index++) ...[
                children[index],
                if (index < children.length - 1)
                  const SizedBox(height: 14),
              ],
            ],
          );
        }
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            for (int index = 0;
                index < children.length;
                index++) ...[
              Expanded(child: children[index]),
              if (index < children.length - 1)
                const SizedBox(width: 14),
            ],
          ],
        );
      },
    );
  }
}
class _DialogDropdown extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Map<String, String> items;
  final ValueChanged<String?>? onChanged;
  const _DialogDropdown({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
    required this.items,
    required this.onChanged,
  });
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _FieldLabel(label),
        const SizedBox(height: 7),
        DropdownButtonFormField<String>(
          value: value,
          isExpanded: true,
          decoration: _dialogInputDecoration(
            hint: '',
            icon: icon,
          ),
          items: items.entries.map((entry) {
            return DropdownMenuItem(
              value: entry.key,
              child: Text(entry.value),
            );
          }).toList(),
          onChanged: onChanged,
        ),
      ],
    );
  }
}
InputDecoration _dialogInputDecoration({
  required String hint,
  required IconData icon,
}) {
  return InputDecoration(
    hintText: hint,
    prefixIcon: Icon(
      icon,
      size: 19,
      color: AdminWebTheme.primary,
    ),
    filled: true,
    fillColor: const Color(0xFFFAFBFD),
    contentPadding: const EdgeInsets.symmetric(
      horizontal: 14,
      vertical: 14,
    ),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(
        color: AdminWebTheme.border,
      ),
    ),
    disabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(
        color: AdminWebTheme.border,
      ),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(
        color: AdminWebTheme.primary,
      ),
    ),
    errorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(
        color: Colors.redAccent,
      ),
    ),
    focusedErrorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(10),
      borderSide: const BorderSide(
        color: Colors.redAccent,
      ),
    ),
  );
}
class _DialogActions extends StatelessWidget {
  final bool saving;
  final VoidCallback onCancel;
  final VoidCallback onSubmit;
  const _DialogActions({
    required this.saving,
    required this.onCancel,
    required this.onSubmit,
  });
  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        const Spacer(),
        OutlinedButton(
          onPressed: saving ? null : onCancel,
          child: const Text('Cancel'),
        ),
        const SizedBox(width: 10),
        FilledButton.icon(
          onPressed: saving ? null : onSubmit,
          icon: saving
              ? const SizedBox(
                  width: 17,
                  height: 17,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: Colors.white,
                  ),
                )
              : const Icon(
                  Icons.save_outlined,
                  size: 18,
                ),
          label: Text(
            saving ? 'Saving...' : 'Save Changes',
          ),
          style: FilledButton.styleFrom(
            backgroundColor: AdminWebTheme.primary,
          ),
        ),
      ],
    );
  }
}
class _StaffAvatar extends StatelessWidget {
  final String imageUrl;
  final String name;
  const _StaffAvatar({
    required this.imageUrl,
    required this.name,
  });
  @override
  Widget build(BuildContext context) {
    final initial = name.trim().isEmpty
        ? 'S'
        : name.trim()[0].toUpperCase();
    return CircleAvatar(
      radius: 22,
      backgroundColor:
          AdminWebTheme.primary.withOpacity(0.10),
      backgroundImage: imageUrl.trim().isEmpty
          ? null
          : NetworkImage(imageUrl.trim()),
      child: imageUrl.trim().isEmpty
          ? Text(
              initial,
              style: const TextStyle(
                color: AdminWebTheme.primary,
                fontWeight: FontWeight.w800,
              ),
            )
          : null,
    );
  }
}
class _RoleBadge extends StatelessWidget {
  final String role;
  const _RoleBadge({
    required this.role,
  });
  @override
  Widget build(BuildContext context) {
    final label = role.isEmpty
        ? 'Attendee'
        : role[0].toUpperCase() +
            role.substring(1).toLowerCase();
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 9,
        vertical: 5,
      ),
      decoration: BoxDecoration(
        color: AdminWebTheme.primary.withOpacity(0.08),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: const TextStyle(
          color: AdminWebTheme.primary,
          fontSize: 9,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}
class _StatusBadge extends StatelessWidget {
  final bool active;
  final String activeText;
  final String inactiveText;
  const _StatusBadge({
    required this.active,
    required this.activeText,
    required this.inactiveText,
  });
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: 9,
        vertical: 5,
      ),
      decoration: BoxDecoration(
        color: active
            ? Colors.green.withOpacity(0.10)
            : Colors.orange.withOpacity(0.10),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        active ? activeText : inactiveText,
        style: TextStyle(
          color: active
              ? Colors.green.shade700
              : Colors.orange.shade800,
          fontSize: 9,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}
class _SmallInfo extends StatelessWidget {
  final String label;
  final String value;
  const _SmallInfo({
    required this.label,
    required this.value,
  });
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(9),
      decoration: BoxDecoration(
        color: const Color(0xFFFAFBFD),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: AdminWebTheme.border,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(
              color: AdminWebTheme.textSecondary,
              fontSize: 8.5,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 3),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              color: AdminWebTheme.textPrimary,
              fontSize: 10,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}
class _FieldLabel extends StatelessWidget {
  final String text;
  const _FieldLabel(this.text);
  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        color: AdminWebTheme.textPrimary,
        fontSize: 10.5,
        fontWeight: FontWeight.w700,
      ),
    );
  }
}
class _LoadingCard extends StatelessWidget {
  const _LoadingCard();
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 250,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(13),
        border: Border.all(
          color: AdminWebTheme.border,
        ),
      ),
      child: const CircularProgressIndicator(),
    );
  }
}
class _MessageCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String message;
  const _MessageCard({
    required this.icon,
    required this.title,
    required this.message,
  });
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(
        horizontal: 24,
        vertical: 54,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(13),
        border: Border.all(
          color: AdminWebTheme.border,
        ),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            color: AdminWebTheme.primary,
            size: 38,
          ),
          const SizedBox(height: 13),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: AdminWebTheme.textPrimary,
              fontSize: 16,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 7),
          Text(
            message,
            textAlign: TextAlign.center,
            style: const TextStyle(
              color: AdminWebTheme.textSecondary,
              fontSize: 11,
            ),
          ),
        ],
      ),
    );
  }
}
