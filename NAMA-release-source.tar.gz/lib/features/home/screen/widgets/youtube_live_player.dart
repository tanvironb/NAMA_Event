import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import 'package:events_app_trueattempt/core/providers.dart';
import 'package:events_app_trueattempt/config/app_colors.dart';

class YoutubeLivePlayer extends ConsumerStatefulWidget {
  const YoutubeLivePlayer({super.key});

  @override
  ConsumerState<YoutubeLivePlayer> createState() => _YoutubeLivePlayerState();
}

class _YoutubeLivePlayerState extends ConsumerState<YoutubeLivePlayer>
    with TickerProviderStateMixin, AutomaticKeepAliveClientMixin {
  YoutubePlayerController? _controller;
  bool _isMinimized = false;
  bool _isClosed = false; // Track if player was closed
  late AnimationController _animationController;
  late Animation<double> _slideAnimation;

  @override
  bool get wantKeepAlive => true; // Keep state alive

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _slideAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
  }

  @override
  void dispose() {
    _controller?.pause(); // Pause before disposing
    _controller?.dispose();
    _animationController.dispose();
    super.dispose();
  }

  String? _extractVideoId(String? url) {
    if (url == null || url.isEmpty) return null;
    return YoutubePlayer.convertUrlToId(url);
  }

  void _initializePlayer(String videoId) {
    _controller?.dispose();
    _controller = YoutubePlayerController(
      initialVideoId: videoId,
      flags: const YoutubePlayerFlags(
        autoPlay: true,
        mute: false,
        enableCaption: true,
        loop: false,
        forceHD: false,
        useHybridComposition: true, // Improves performance on Android
      ),
    );

    _animationController.forward();
  }

  @override
  Widget build(BuildContext context) {
    super.build(context); // Required for AutomaticKeepAliveClientMixin
    
    final activeLiveSession = ref.watch(activeLiveSessionProvider);

    return activeLiveSession.when(
      data: (session) {
        if (session == null || session.liveStreamUrl.isEmpty || _isClosed) {
          // No active live session with stream URL, hide the player
          if (_controller != null && (session == null || session.liveStreamUrl.isEmpty)) {
            _controller!.pause(); // Pause before disposing
            _controller!.dispose();
            _controller = null;
            _isClosed = false; // Reset closed state when session ends
            _animationController.reset();
          }
          return const SizedBox.shrink();
        }

        final videoId = _extractVideoId(session.liveStreamUrl);
        if (videoId == null) {
          return const SizedBox.shrink();
        }

        // Initialize player if not already done or video changed
        if (_controller == null || _controller!.initialVideoId != videoId) {
          _initializePlayer(videoId);
        }

        return AnimatedBuilder(
          animation: _slideAnimation,
          builder: (context, child) {
            return Transform.translate(
              offset: Offset(0, (1 - _slideAnimation.value) * 200),
              child: Opacity(
                opacity: _slideAnimation.value,
                child: Container(
                  margin: const EdgeInsets.all(8.0),
                  decoration: BoxDecoration(
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3),
                        blurRadius: 10,
                        offset: const Offset(0, -2),
                      ),
                    ],
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: _isMinimized
                        ? _buildMinimizedPlayer(session.title)
                        : _buildFullPlayer(session.title),
                  ),
                ),
              ),
            );
          },
        );
      },
      loading: () => const SizedBox.shrink(),
      error: (error, stack) => const SizedBox.shrink(),
    );
  }

  Widget _buildFullPlayer(String sessionTitle) {
    return Container(
      height: 250,
      color: Colors.black,
      child: Column(
        children: [
          // Header with session title and controls
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            color: AppColors.namaNavyBlue.withOpacity(0.95),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    sessionTitle,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.close_fullscreen, color: Colors.white, size: 20),
                  onPressed: () {
                    setState(() {
                      _isMinimized = true;
                    });
                  },
                ),
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.white, size: 20),
                  onPressed: () {
                    setState(() {
                      _isClosed = true;
                    });
                    _controller?.pause();
                    _animationController.reverse();
                  },
                ),
              ],
            ),
          ),
          // YouTube Player - single instance
          Expanded(
            child: _controller != null
                ? RepaintBoundary(
                    child: YoutubePlayer(
                      key: ValueKey(_controller!.initialVideoId),
                      controller: _controller!,
                      showVideoProgressIndicator: true,
                      progressIndicatorColor: AppColors.goldenYellow,
                      onReady: () {
                        _controller!.addListener(() {});
                      },
                    ),
                  )
                : const Center(
                    child: CircularProgressIndicator(
                      color: AppColors.goldenYellow,
                    ),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _buildMinimizedPlayer(String sessionTitle) {
    return Container(
      height: 80,
      color: AppColors.namaDeepNavy,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () {
            setState(() {
              _isMinimized = false;
            });
          },
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(
              children: [
                // Play icon indicator
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: AppColors.namaNavyBlue,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(
                    Icons.play_arrow_rounded,
                    color: AppColors.goldenYellow,
                    size: 32,
                  ),
                ),
                const SizedBox(width: 12),
                // Session title
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        'LIVE NOW',
                        style: TextStyle(
                          color: AppColors.goldenYellow,
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        sessionTitle,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                // Expand button
                IconButton(
                  icon: const Icon(Icons.open_in_full, color: Colors.white70, size: 20),
                  onPressed: () {
                    setState(() {
                      _isMinimized = false;
                    });
                  },
                ),
                // Close button
                IconButton(
                  icon: const Icon(Icons.close, color: Colors.white70, size: 20),
                  onPressed: () {
                    setState(() {
                      _isClosed = true;
                    });
                    _controller?.pause();
                    _animationController.reverse();
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}