#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\Users\User\flutter"
export "FLUTTER_APPLICATION_PATH=D:\Internship\Nama Foundation\nama-app\events_app_trueattempt"
export "FLUTTER_FRAMEWORK_SWIFT_PACKAGE_PATH=D:\Internship\Nama Foundation\nama-app\events_app_trueattempt\ios\Flutter\ephemeral\Packages\.packages\FlutterFramework"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_TARGET=lib\main.dart"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.6"
export "FLUTTER_BUILD_NUMBER=26"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
